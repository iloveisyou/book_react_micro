import { Counter } from "./Counter";

const App = () => (
  <div>
    <Counter />
    <Counter />
  </div>
);

export default App;
